
package com.example.backend.service;

import com.example.backend.dto.RegisterRequest;
import com.example.backend.entity.Student;
import com.example.backend.repository.StudentRepository;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final StudentRepository studentRepository;

    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public AuthService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public String register(RegisterRequest request) {

        // Check whether the email already exists
        if (studentRepository.existsByEmail(request.getEmail())) {
            return "Email already registered";
        }

        // Create a new student object
        Student student = new Student();

        student.setName(request.getName());
        student.setEmail(request.getEmail());

        // Hash the password before saving
        student.setPassword(passwordEncoder.encode(request.getPassword()));

        // Save student details in the database
        studentRepository.save(student);

        return "Student registered successfully";
    }
}

//1. StudentRepository – Connects this service to the database.
//2. BCryptPasswordEncoder – Protects the password by hashing it.
//3. register() – Handles the registration process.
//4. existsByEmail() – Checks whether the email is already registered.
//5. new Student() – Creates a new student object.
//6. setName() and setEmail() – Add student details.
//7. passwordEncoder.encode() – Hashes the password.
//8. save() – Stores student details in MySQL.