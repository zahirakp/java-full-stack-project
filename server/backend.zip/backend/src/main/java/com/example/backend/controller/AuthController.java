
package com.example.backend.controller;

import com.example.backend.dto.RegisterRequest;
import com.example.backend.service.AuthService;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request) {
        return authService.register(request);
    }
}
//1. @RestController – Makes this class handle API requests.
//2. @RequestMapping("/api/auth") – Sets the common API URL.
//3. AuthService – Connects the controller to registration logic.
//4. @PostMapping("/register") – Handles student registration requests.
//5. @RequestBody – Receives student details from the frontend as JSON.
//6. authService.register(request) – Sends those details to the service for registration.
